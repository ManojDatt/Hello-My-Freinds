class RemoveColumnFromLike < ActiveRecord::Migration
  def change
    remove_column :likes, :post_id, :string
    remove_column :likes, :user_id, :string
    remove_column :likes, :comment_id, :string
  end
end
