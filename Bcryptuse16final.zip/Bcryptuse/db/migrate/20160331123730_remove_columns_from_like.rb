class RemoveColumnsFromLike < ActiveRecord::Migration
  def change
    remove_column :likes, :comment_id, :string
    remove_column :likes, :post_id, :string
  end
end
