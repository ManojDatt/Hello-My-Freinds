class AddColumnsToLike < ActiveRecord::Migration
  def change
    add_column :likes, :user_id, :integer
    add_column :likes, :post_id, :integer
    add_column :likes, :comment_id, :integer

 	add_column :comments, :commenter, :string
 	add_column :posts, :poster, :string
 	 
  end
end
