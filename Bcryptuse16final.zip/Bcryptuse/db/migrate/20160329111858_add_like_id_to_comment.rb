class AddLikeIdToComment < ActiveRecord::Migration
  def change
    add_column :comments, :like_id, :integer
  end
end
