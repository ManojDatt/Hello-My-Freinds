class AddCommentIdToPost < ActiveRecord::Migration
  def change
    add_column :posts, :comment_id, :integer
       add_column :posts, :like_id, :integer

  end
end
