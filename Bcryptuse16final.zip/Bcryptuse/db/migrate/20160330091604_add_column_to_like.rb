class AddColumnToLike < ActiveRecord::Migration
  def change
    add_column :likes, :liker, :string
  end
end
