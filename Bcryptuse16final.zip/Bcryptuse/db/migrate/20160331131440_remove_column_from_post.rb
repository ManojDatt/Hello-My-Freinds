class RemoveColumnFromPost < ActiveRecord::Migration
  def change
    remove_column :posts, :comment_id, :string
  end
end
