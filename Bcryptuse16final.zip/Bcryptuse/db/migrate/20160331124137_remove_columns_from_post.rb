class RemoveColumnsFromPost < ActiveRecord::Migration
  def change
    remove_column :posts, :like_id, :string
    remove_column :comments, :like_id, :string
  end
end
