class AddColumnsToUser < ActiveRecord::Migration
  def change
    add_column :users, :post_id, :integer, index: true
    add_column :users, :comment_id, :integer , index: true
    add_column :users, :like_id, :integer , index: true
  end
end
