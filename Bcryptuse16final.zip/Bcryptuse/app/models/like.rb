class Like < ActiveRecord::Base
	belongs_to :likable , polymorphic: true
	belongs_to :comment
	belongs_to :post
	belongs_to :user
end
