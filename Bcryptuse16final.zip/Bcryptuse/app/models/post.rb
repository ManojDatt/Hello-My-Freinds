class Post < ActiveRecord::Base
	attr_accessor :content
	belongs_to :user
	has_many :likes , as: :likable
	has_many :comments
	mount_uploader :image, ImageUploader
end
