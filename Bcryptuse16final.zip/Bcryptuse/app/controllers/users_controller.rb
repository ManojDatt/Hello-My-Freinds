class UsersController < ApplicationController
  
before_action :selfid, only:[:edit,:update]

def new
@user=User.new
end
	def create
    user = User.new(user_params)
    if user.save
    
      redirect_to home_path
    else
      redirect_to new_user_path
    end
  end

  def edit
  end
  
  def update
    @li=Like.where(user_id:current_user.id)
    @li.update_all(liker:params[:name])

     @po=Post.where(user_id:current_user.id)
    @po.update_all(poster:params[:name])

     @co=Comment.where(user_id:current_user.id)
    @co.update_all(commenter:params[:name])
    if @user.update(user_params)
      flash[:success]="Profile Updated  !"
      redirect_to home_path
   
  else
    redirect_to home_path
  end
end

private

  def user_params
    params.require(:user).permit(:name, :email, :dob,:adres,:password, :password_confirmation)
  end
  def selfid
    @user=User.find(params[:id])
  end
end
