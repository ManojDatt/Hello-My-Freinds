class PostsController < ApplicationController
  before_filter :authorize     # this method will restrics unauthorize access to these Actions
	before_action :idset , only:[:show,:edit,:destroy,:likeonpost,:update,:postcomment]

  #===========================  INDEX  ACTION =======================================
  def index
  
		@post1=Post.where.not(user_id:session[:user_id]).order("created_at DESC")
		if session[:user_id]
      @us=User.find(session[:user_id])
			@post=Post.where("user_id=?",@us).order("created_at DESC")
		end
  end

   #===========================  NEW  ACTION =======================================
 
  def new
  @post=Post.new
  end

   #===========================  SHOW  ACTION =======================================
 
  def show
  end

   #===========================  CREATE  ACTION =======================================
 
  def create
   @post=Post.new(param_set)
   @post.user_id=session[:user_id]
   @post.poster=current_user.name
   if @post.save
    flash[:success] = "Posted Succesfully.."
  	redirect_to home_path #notice: "Posted Succesfully.."
     
   else
  	render'new'
   end
  end

 #===========================  EDIT  ACTION =======================================
 

  def edit
  end

   #===========================  UPDATE  ACTION =======================================
 

  def update
    if @post.update(param_set)
       flash[:success] = "Post Updated...."
      redirect_to home_path#notice:"Post updated.."
      

    else
      render 'edit'
    end

  end

   #===========================  DESTROY ACTION =======================================
 
  def destroy
    @post.destroy
    flash[:success] = "Post Deleted Succesfully.."
    redirect_to home_path #notice:"Post deleted succesfully.."
    
  end
#============================#####################=============================
 #===========================  POST RELATED  ACTIONS =======================================

  #============================#####################=============
  def likeonpost

    #=============================Single like===============================
    @pos=Post.find_by(id:params[:id])
    if (@pos.likes.where(user_id:session[:user_id]).count)==0
    #=======================================================================
    @like=@post.likes.create(:user_id => session[:user_id],:liker=>current_user.name)

    
     if @like.save
      flash[:success] ="You liked this post.."
      redirect_to home_path
     end
    else
      flash[:alert] ="You already liked this post.."
       redirect_to home_path
    end

  end

  def likeoncomment
#==================================Single Like====================================
 @com=Comment.find_by(id:params[:comment_id])
    if (@com.likes.where(user_id:session[:user_id]).count)==0
  #=================================================================    

    @comment=Comment.find_by(id:params[:comment_id])
     @like=@comment.likes.create(:user_id => session[:user_id],:liker=>current_user.name)
   

    if @like.save
      flash[:success] ="You liked this comment.."
     redirect_to post_path
    end
   else
    flash[:alert] ="You have already liked this comment.."
  
     redirect_to post_path
   end 
end

 #===========================  ################### =======================================
 
  def postcomment
   @comment=@post.comments.create(param_set)
   @comment.commenter=current_user.name
   @comment.user_id=session[:user_id]
     if@comment.save
      flash[:success] ="You commented on this post.."
   
      redirect_to post_path 
       else
      redirect_to home_path
    end
  end
#======================#####################=========================================

def unlike_comment
 @li=Like.find(params[:like_id])
 @li.destroy
 flash[:success]="You Unliked this comment..!"
 redirect_to post_path
end 


def unlike_post
 @li=Like.find(params[:like_id])
 @li.destroy
 flash[:success]="You Unliked this post..!"
 redirect_to home_path
end
 #===========================  PRIVATE  ACTION =======================================

  private
  def param_set
  	params.require(:post).permit(:discription,:title,:content,:image)
  end

  def idset
  	@post=Post.find(params[:id])
  end

end
