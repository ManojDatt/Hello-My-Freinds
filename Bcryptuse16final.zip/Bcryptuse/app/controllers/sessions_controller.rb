class SessionsController < ApplicationController

  def new
   
  end

  def create
    user = User.find_by_email(params[:user][:email])
      if user && user.authenticate(params[:user][:password])
  
      session[:user_id] = user.id
      flash[:success]="Login successful.."
      redirect_to  home_path  
    else
         flash[:alert]="Email or Password may be wrong...."
      redirect_to new_session_path 
    end
  end

  def destroy
    session[:user_id] = nil
    flash[:success]="Log Out successful !"
    redirect_to home_path
  end
end
